const imgUrl=[
    {
        url: 'images/venom.jpg',
       
    },
    {
        url: 'images/dune.jpg',
       
    },
    {
        url: 'images/last_night.jpg'
    },
    {
        url: 'images/no_time.jpg'
    }
    
]
export default imgUrl