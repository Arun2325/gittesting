import { BUY_ICECREAM } from './IceTypes'

export const buyIceCream = () => {
    return{ 
        type: BUY_ICECREAM
    }
}